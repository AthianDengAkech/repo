package com.tigrek.iuea.Aug2018;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Point;

import javax.swing.JPanel;

public class BackPanel extends JPanel {
	int [] x= {100,140,145};
	int [] y= {200,230,250};
	int sw=600;
	int sh=600;
	public BackPanel() {
		super();
		JPanel p=new JPanel();
		setLayout(null);
		add(p);
		p.setBounds(200,200,100,100);
		p.setBackground(Color.red);
		
	}
	
	public void paintComponent(Graphics g)
	{
		super.paintComponent(g);
		g.drawOval(100, 100, 50, 50);
		int del;
		int n=20;
		del=sw/n;
		for(int i=0;i<n;i++)
		{
			g.drawLine(i*del, 0, 600,i*del);;
			g.drawLine(sw-i*del, 0, 0,i*del);;
		}
	}
}

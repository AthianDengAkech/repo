package com.tigrek.iuea.Aug2018;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Point;

import javax.swing.JPanel;

public class BackPanel extends JPanel {
	int [] x= {100,140,145};
	int [] y= {200,230,250};
	public BackPanel() {
		super();
		JPanel p=new JPanel();
		setLayout(null);
		add(p);
		p.setBounds(200,200,100,100);
		p.setBackground(Color.red);
		
	}
	
	public void paintComponent(Graphics g)
	{
		super.paintComponent(g);
		g.drawOval(100, 100, 50, 50);
		for(int i=0;i<3;i++)
		{
			g.drawRect(x[i], y[i], 60, 70);;
		}
	}
}

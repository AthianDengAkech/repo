
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int [][] a= {{10,10,20},{20,30,45},{43,65,76}};
		for(int j=0;j<3;j++)
		{
			for(int i=0;i<3;i++)
			{
				System.out.print(a[j][i]+" ");
			}
			System.out.println();
		}

	}

}
